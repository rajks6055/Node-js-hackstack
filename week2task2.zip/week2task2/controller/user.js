const bcrypt = require('bcrypt');
const path=require('path')
const User = require('../model/user.js');
const jwt = require('jsonwebtoken');
const secret = 'helloworld$%^&123'; 
const express = require('express')

const displayUser=async(req,res)=>{
  try{
    const Users=await User.find();
    res.status(200).json({message:Users})
  }catch(err){
    console.log(err);
    res.status(500).json({message:"Server error"});
  }
}
const handleCreateUser = async (req, res) => {
  const { firstName, lastName, email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (existingUser) return res.status(400).json({ message: 'Email already exists' });

    const hashed = await bcrypt.hash(password, 10);
    const newUser = new User({ firstName, lastName, email, password: hashed });

    await newUser.save();
    res.status(201).json({ message: 'Registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

const handleLoginUser = async (req, res) => {
  const { email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email });
    if (!existingUser) return res.status(400).json({ message: 'Email not registered' });

    const match = await bcrypt.compare(password, existingUser.password);
    if (!match) return res.status(401).json({ message: 'Password is incorrect' });

    const token = jwt.sign(
      { id: existingUser._id, email: existingUser.email },
      secret,
      // { expiresIn: '1h' }
    );
    res.status(200).json({ message: 'Login successful', token });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

module.exports = { displayUser,handleCreateUser, handleLoginUser };
