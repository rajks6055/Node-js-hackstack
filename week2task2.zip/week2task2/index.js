const express = require('express')
const path=require('path')
const { displayUser,handleCreateUser, handleLoginUser } = require('./controller/user.js');
const requireAuth=require('./middleware/auth.js')
const connectDb=require('./connection/mongodb.js')
const {createTodo,displayTodos,updateTodo,deleteTodo}=require('./controller/todo.js')
const app = express()
const port = 3000

//middleware
app.set('view engine','ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
//mongodb connection
connectDb();

//routes
app.get('/', (req, res) => {
    res.render('signup');
})
app.get('/signin',(req,res)=>{
    res.render('signin');
})
app.post('/',handleCreateUser);
app.post('/signin',handleLoginUser);
// app.get('/user',requireAuth,(req,res)=>{
  // res.render('todo')
// })
app.get('/user',requireAuth,displayUser);

//crud on todo app
app.get('/user/:userid',requireAuth,displayTodos);
app.post('/user/:userid',requireAuth,createTodo);
app.delete('/user/:userid/:id',requireAuth,deleteTodo);
app.patch('/user/:userid/:id',requireAuth,updateTodo);


app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})