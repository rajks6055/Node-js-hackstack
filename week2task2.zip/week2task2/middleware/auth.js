const jwt=require('jsonwebtoken')
const secret = 'helloworld$%^&123'; 

const requireAuth=(req,res,next)=>{
    const header=req.headers.authorization;
    if(!header || !header.startsWith('Bearer ')){ 
       return res.status(401).json({message:"token Missing or malfunctioned",header});
    }
    const token=header.split(" ")[1];
    try{
        const decoded=jwt.verify(token,secret);
        req.user=decoded;
        next();
    }catch(err){
        console.error(err);
        return res.status(403).json({message:"invalid or expired token"})
    }
}
module.exports=requireAuth;