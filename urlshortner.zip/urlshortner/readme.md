step 1: npm install
step 2:node index.js