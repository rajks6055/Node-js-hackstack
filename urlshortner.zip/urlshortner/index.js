const express = require('express');
const { nanoid } = require('nanoid');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;

const dataFile = path.join(__dirname, 'urls.json');

app.set('view engine', 'ejs');
app.set('views', './views');
app.use(express.urlencoded({ extended: true }));

function readUrlData() {
  if (!fs.existsSync(dataFile)) return {};
  const rawData = fs.readFileSync(dataFile);
  return JSON.parse(rawData);
}


function writeUrlData(data) {
  fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
}

app.get('/', (req, res) => {
  const urlDatabase = readUrlData();
  res.render('index', { urlDatabase });
});


function validateUrl(req, res, next) {
  const url = req.body.longUrl;
  if (!url || !url.startsWith('http')) {
    return res.status(400).send('Invalid URL submitted.');
  }
  next();
}

app.post('/shorten', validateUrl, (req, res) => {
  const longUrl = req.body.longUrl;
  const shortId = nanoid(6);
  const urlDatabase = readUrlData();

  urlDatabase[shortId] = longUrl;
  writeUrlData(urlDatabase);

  res.redirect('/');
});


app.get('/:shortId', (req, res) => {
  const shortId = req.params.shortId;
  const urlDatabase = readUrlData();
  const longUrl = urlDatabase[shortId];

  if (longUrl) {
    res.redirect(longUrl);
  } else {
    res.status(404).send(`<h1>404 - Short URL not found</h1>`);
  }
});

app.listen(port, () => {
  console.log(`URL Shortener running at http://localhost:${port}`);
});
