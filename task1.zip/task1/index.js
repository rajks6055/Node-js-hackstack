const express = require('express')
const path=require('path')
const { handleCreateUser, handleLoginUser } = require('./controller/user.js');
const requireAuth=require('./middleware/auth.js')
const connectDb=require('./connection/mongodb.js')
const app = express()
const port = 3000

app.set('view engine','ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(express.urlencoded({ extended: false }));

connectDb();

app.get('/', (req, res) => {
    res.render('signup');
})
app.get('/signin',(req,res)=>{
    res.render('signin');
})
app.post('/',handleCreateUser);
app.post('/signin',handleLoginUser)

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})