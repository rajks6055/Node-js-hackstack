const jwt=require('jsonwebtoken')
const secret = 'helloworld$%^&123'; 

const requireAuth=(req,res)=>{
    const header=req.headers.authorization;
    if(!header || !header.startWith('Bearer')){
       return res.status(401).json({message:"token Missing"});
    }
    const token=header.split(" ")[1];
    try{
        const decoded=jwt.verify(token,secret);
        req.user=decoded;
    }catch(err){
        console.error(err);
        return res.status(403).json({message:"invalid or expired token"})
    }
}
module.exports=requireAuth;